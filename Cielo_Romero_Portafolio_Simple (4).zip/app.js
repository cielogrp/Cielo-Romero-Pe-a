const btnTheme = document.getElementById('btnTheme');
const btnLang = document.getElementById('btnLang');
let lang = 'es';

btnTheme.addEventListener('click', () => {
  const theme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', theme);
  btnTheme.textContent = theme === 'dark' ? '☀️' : '🌙';
});

const translations = {
  en: {
    home: 'Home', profile: 'Profile', education: 'Education', contact: 'Contact',
    download: 'Download info', greeting: "Hi! I'm Cielo Geraldine Romero Peña",
    quote: "“The process that weighs on you today will be your greatest reward tomorrow.”",
    profileTitle: 'Profile',
    profileText: "I'm 18 years old and from Cusco. I study Business Administration at Universidad Católica San Pablo. I'm creative, adaptable and empathetic. I love art, theatre, marketing and gastronomy. I value responsibility, respect and punctuality. I've participated in volunteer projects supporting children and women, strengthening my social commitment.",
    educationTitle: 'Education',
    edu1: 'Monteverde School - Cusco (until 2023)',
    edu2: 'Universidad Católica San Pablo (since 2024)',
    languages: 'Languages: Intermediate English · Basic German',
    contactTitle: 'Contact',
    footer: '© 2024 Cielo Geraldine Romero Peña — Personal portfolio'
  },
  es: {}
};

btnLang.addEventListener('click', () => {
  lang = lang === 'es' ? 'en' : 'es';
  btnLang.textContent = lang === 'es' ? 'EN' : 'ES';
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (translations[lang] && translations[lang][key]) {
      el.textContent = translations[lang][key];
    }
  });
});
